

package If_Waktu;



public class If_Kondisi2 {
    public static void main(String[] args) {
        
        int waktu ;
        
        waktu = 12 ;
        
        if ( waktu <= 10) {
            System.out.println("Selamat Pagi");
        } else if ( waktu <= 15 ) {
            System.out.println("selamat siang");
        } else {
            System.out.println("selamat malam"); }
            
            
            
            
}
    
}


