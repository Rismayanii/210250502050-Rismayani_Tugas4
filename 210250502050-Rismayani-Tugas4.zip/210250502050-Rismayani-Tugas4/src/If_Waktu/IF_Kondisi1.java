
package If_Waktu;


public class IF_Kondisi1 {
    public static void main(String[] args) {
        
        int waktu ;
        
        waktu = 18 ;
        
        if ( waktu < 12)
            System.out.println("Selamat Pagi");
        else {
            System.out.println("Selamat Malam");
        }
    
    }
}
