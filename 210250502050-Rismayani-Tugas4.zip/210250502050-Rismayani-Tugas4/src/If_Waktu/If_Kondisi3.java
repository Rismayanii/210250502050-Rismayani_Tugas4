
package If_Waktu;


public class If_Kondisi3 {
     public static void main(String[] args) {
         
        int waktu ;
        
        waktu = 9 ;
        
        if ( waktu <= 10) {
            System.out.println("Selamat Pagi");
        } else if ( waktu < 15 ) {
            System.out.println("selamat siang");
        } else if ( waktu<=18   ) {
            System.out.println("selamat sore"); 
        } else {
             System.out.println("selamat malam");}
     }
}
